# Experience Skill Suite Final

这是一套 3 层技能，用来把岗位经验逐步做成知识产品。

## 目录结构

- `experience-to-asset/`
  第一层，入口层。
  作用：低门槛引入、先给框、先判断方向、判断是否值得进入提炼。

- `experience-deep-extract/`
  第二层，提炼层。
  作用：把口述故事和上传材料合并，提炼成案例、判断、踩坑、阶段和 SOP 候选模块。

- `experience-package-build/`
  第三层，封装层。
  作用：先判断受众、价值承诺、内容密度和形式，再决定做成什么，并启动第一版成品。

## 推荐使用顺序

1. 先用 `experience-to-asset`
2. 内容足够后，再用 `experience-deep-extract`
3. 第二层判断 `可进入第三层` 后，再用 `experience-package-build`

## 三层分别解决什么问题

### 1. `experience-to-asset`

解决：

- 用户只有一个模糊想法，不知道怎么开始
- 用户不知道自己的经验值不值钱
- 用户不知道先做文章、PDF、表格，还是别的

这一层会：

- 先给框
- 先讲受众
- 按内容量先推荐形式
- 判断当前内容够不够往下走

### 2. `experience-deep-extract`

解决：

- 用户已经讲出了案例或踩坑，但内容还散
- 用户上传了表格、文档、截图、复盘，需要提炼而不是润色
- 需要把经验抽成后续可封装的原料

这一层会输出：

- 故事与踩坑
- 判断依据
- 经验地图
- `0-1 / 1-5 / 5-10`
- SOP 候选模块 + 缺失信息 + 封装状态

### 3. `experience-package-build`

解决：

- 第二层已经提炼好了，但还不知道最适合做成什么
- 需要判断现在能做轻内容、工具表格、PDF 手册，还是更重的产品
- 需要启动第一版成品，而不只是讲抽象建议

这一层会：

- 先判断受众
- 再判断价值承诺
- 再判断内容密度
- 再选形式
- 再检查该形式的内容标准是否满足
- 最后直接开始做第一版，或给出骨架 + 缺失项

## 关键规则

### 轻型输出和重型输出的区别

- 文章 / 小红书内容 / 单篇案例内容：
  可以在有真实案例和核心判断时先推进

- PDF / PPT / 表格 / 网页 / 系统型手册：
  默认要求材料驱动
  没有材料时，只能做较薄的初版或骨架版，不能假装已经能做完整成品

### 上传材料后的处理方式

上传的文档、表格、截图、复盘，默认都当作“原料”。

除非用户明确要求“修改这份现有文档”，否则不要直接在原文档上润色。要先提炼，再重组。

### 第三层最重要的原则

**形式是结果，不是起点。**

必须按这个顺序判断：

`受众 -> 价值承诺 -> 内容密度 -> 形式 -> 制作`

## 给 Claude / Codex 的使用建议

### 如果你是放到 GitHub

直接上传整个文件夹：

- `experience-skill-suite-final/`
  - `README.md`
  - `experience-to-asset/`
  - `experience-deep-extract/`
  - `experience-package-build/`

### 如果你是给 Codex 自动发现

不要只放这个总文件夹。

应把 3 个技能目录直接放到 `$CODEX_HOME/skills/` 下作为并列目录：

- `$CODEX_HOME/skills/experience-to-asset/`
- `$CODEX_HOME/skills/experience-deep-extract/`
- `$CODEX_HOME/skills/experience-package-build/`

### 如果你是给 Claude 使用

Claude 不会天然保证 3 层按固定顺序自动跑。

最稳的方式是显式告诉它：

1. 先用 `experience-to-asset`
2. 再用 `experience-deep-extract`
3. 最后用 `experience-package-build`

## 当前版本说明

这是已经合并了以下规则的版本：

- 内容量决定推荐形式
- 形式决定材料门槛
- 材料门槛决定能不能进入制作
- 内容标准决定成品有没有价值
